package com.example.calculadora;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {
    double num1,num2;
    TextView resultado;
    EditText valor1,valor2;
    Button btn;
    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        resultado = findViewById(R.id.textResult);
        valor1 = findViewById(R.id.textNum1);
        valor2 = findViewById(R.id.TextNum2);
        btn = findViewById(R.id.button2);
        Spinner operadores = findViewById(R.id.spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.operadores, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        operadores.setAdapter(adapter);
        operadores.setOnItemSelectedListener(this);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {



                    String SelecionarOperador = operadores.getSelectedItem().toString();
                    num1 = Double.parseDouble(valor1.getText().toString());
                    num2= Double.parseDouble(valor2.getText().toString());
                    double r = 0;

                    if (valor1.getText().toString().isEmpty() || valor2.getText().toString().isEmpty()) {
                        Toast.makeText(MainActivity.this, "Por favor, preencha ambos os valores", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    switch (SelecionarOperador) {
                        case "Somar":
                        r = (num1 + num2);
                        break;

                        case "Diminuir":
                            r = (num1 - num2);
                            break;

                        case "Multiplicar":
                            r = (num1 * num2);
                            break;

                        case "Dividir":
                            if (num2 == 0){
                                throw new ArithmeticException("Divisão por zero não é permitida!!");
                            }
                            r = (num1 / num2);
                            break;
                        default:
                            throw new IllegalArgumentException("Operação Invalida!!");


                    }
                    resultado.setText("O valor da " + SelecionarOperador + " é : " + r);
                }catch(ArithmeticException e) {
                    Toast.makeText(MainActivity.this, "Por favor, preencha ambos os valores", Toast.LENGTH_SHORT).show();


                }catch(IllegalArgumentException e) {
                    Toast.makeText(MainActivity.this, "Por favor, preencha ambos os valores", Toast.LENGTH_SHORT).show();


                }



            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String SelecionarOperador = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}